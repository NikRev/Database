﻿using System.Windows;
// Ссылка на пространство имен библиотеки DatabaseController
using DatabaseController;
namespace WpfApp
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            string connection_str = @"Data Source=RDRAM\SQLEXPRESS; Initial Catalog=test_db; Integrated Security=true;";
            // Установить строку подключения впервые.
            Database.GetInstance(connection_str);
        }
    }
}
