﻿using System;
using System.Windows;
// Подключить пространство имен библиотеки DatabaseController.
using DatabaseController;
namespace WpfApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Database db;
        public MainWindow()
        {
            InitializeComponent();
            db = Database.GetInstance();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string login = login_tb.Text;
            string password = password_tb.Text;
            string query = "SELECT COUNT(*) " +
            "FROM users " +
            "WHERE login = @login AND password = @password";
            Parameter[] par =
            {
                new Parameter("@login", login),
                new Parameter("@password", password),
            };
            object result = db.GetScalar(query, par);
            try
            {
                if ((int)result > 0)
                {
                    MessageBox.Show("Авторизация прошла успешно");
                    return;
                }
                throw new Exception("Неверные логин или пароль");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
