﻿using NUnit.Framework;
using DatabaseController;

namespace DatabaseController.Tests
{
    [TestFixture]
    public class DatabaseTests
    {
        public string sqlstr = @"Data Source=RDRAM\SQLEXPRESS;Initial Catalog=test_db;Integrated Security=true;";
        public Database database;

        [Test]
        public void Database_InstanceCreation_Test()
        {
            database = Database.GetInstance(sqlstr);
            Assert.NotNull(database);
        }

        [Test]
        public void Database_IsSingleton_Test()
        {
            Database db1 = Database.GetInstance(sqlstr);
            Database db2 = Database.GetInstance(sqlstr);
            Assert.AreSame(db1, db2);
        }

        [Test]
        public void Database_SetConnectionString_Test()
        {
            string connectionString = sqlstr;
            database = Database.GetInstance(connectionString);
            Assert.AreEqual(connectionString, sqlstr);
        }

        [Test]
        public void Database_ExecuteQuery_NoParameters_Test()
        {
            database = Database.GetInstance(sqlstr);
            string query = "INSERT INTO users VALUES ('user2', 123457)";
            int rowsAffected = database.Execute(query);
            Assert.GreaterOrEqual(rowsAffected, 0);
        }

        [Test]
        public void Database_ExecuteQuery_WithParameters_Test()
        {
            database = Database.GetInstance(sqlstr);
            string query = "INSERT INTO YourTable VALUES (@Param1, @Param2)";
            Parameter[] parameters = new Parameter[]
            {
                new Parameter("@Param1", 1),
                new Parameter("@Param2", "Test")
            };
            int rowsAffected = database.Execute(query, parameters);
            Assert.GreaterOrEqual(rowsAffected, 0);
        }

        [Test]
        public void Database_GetScalar_Test()
        {
            database = Database.GetInstance(sqlstr);
            string query = "SELECT COUNT(*) FROM users";
            object result = database.GetScalar(query);
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<int>(result);
        }

        [Test]
        public void Database_GetRowsData_Test()
        {
            database = Database.GetInstance(sqlstr);
            string query = "SELECT * FROM users";
            object[][] rows = database.GetRowsData(query);
            Assert.IsNotNull(rows);
            Assert.IsNotEmpty(rows);
        }

        [Test]
        public void Database_ExecuteQuery_ExceptionHandling_Test()
        {
            database = Database.GetInstance(sqlstr);
            string query = "INVALID SQL QUERY";
            int rowsAffected = database.Execute(query);
            Assert.AreEqual(0, rowsAffected);
        }

        //[Test]
        //public void Database_SetConnectionString_ExceptionHandling_Test()
        //{
        //    database = Database.GetInstance();
         //   string invalidConnectionString = "InvalidConnectionString";
         //   database.GetInstance(invalidConnectionString);
        //    Assert.IsNull(sqlstr);
        //}

        [Test]
        public void Database_GetScalar_NoResults_Test()
        {
            Database db = Database.GetInstance();
            string query = "SELECT COUNT(*) FROM users WHERE ConditionThatYieldsNoResults";
            object result = db.GetScalar(query);
            Assert.IsNull(result);
        }
    }
}
